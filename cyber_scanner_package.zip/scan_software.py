import re

def scan_software(content, grouped_patterns):
    results = []
    for p in grouped_patterns["software"]:
        try:
            pattern = re.compile(p["pattern"])
            matches = pattern.findall(content)
            if matches:
                results.append({
                    "type": "software",
                    "pattern": p["pattern"],
                    "matches": matches,
                    "risk": p.get("risk", 5)
                })
        except re.error as e:
            print(f"Regex error in software pattern: {p['pattern']} → {e}")
    return results
