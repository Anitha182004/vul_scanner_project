import os
from patterns import pattern_list
from scan_web import scan_web
from scan_network import scan_network
from scan_software import scan_software
from scan_api import scan_api
from colorama import init, Fore, Style

init()

grouped_patterns = {
    "web": [p for p in pattern_list if p["type"] == "web"],
    "network": [p for p in pattern_list if p["type"] == "network"],
    "software": [p for p in pattern_list if p["type"] == "software"],
    "api": [p for p in pattern_list if p["type"] == "api"]
}

def get_severity_label(score):
    if score <= 3:
        return "Low"
    elif score <= 6:
        return "Medium"
    elif score <= 8:
        return "High"
    else:
        return "Critical"

def scan_file(file_path):
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        print(Fore.CYAN + f"\nScanning: {file_path}" + Style.RESET_ALL)

        web = scan_web(content, grouped_patterns)
        net = scan_network(content, grouped_patterns)
        soft = scan_software(content, grouped_patterns)
        api = scan_api(content, grouped_patterns)

        all_findings = web + net + soft + api

        if all_findings:
            for finding in all_findings:
                severity = get_severity_label(finding.get("risk", 5))
                color = {
                    "Low": Fore.GREEN,
                    "Medium": Fore.YELLOW,
                    "High": Fore.RED,
                    "Critical": Fore.MAGENTA
                }.get(severity, Fore.WHITE)
                print(color + f"  [{finding['type'].upper()}] {severity} - {finding['pattern']}")
                for match in finding["matches"]:
                    print(Fore.LIGHTBLACK_EX + f"    - {match}")
        else:
            print(Fore.GREEN + "✔️ No vulnerabilities found.")

    except Exception as e:
        print(Fore.RED + f"❌ Error reading file {file_path}: {e}")

def scan_directory(path):
    for root, _, files in os.walk(path):
        for file in files:
            if file.endswith((".html", ".js", ".py", ".txt", ".env", ".conf", ".cfg")):
                scan_file(os.path.join(root, file))

if __name__ == "__main__":
    folder = input("Enter folder path to scan: ")
    scan_directory(folder)
