import tkinter as tk
from scanner_gui import launch_url_scanner, launch_folder_scanner

url_scanner_window = None
folder_scanner_window = None

def main_gui():
    global url_scanner_window, folder_scanner_window

    root = tk.Tk()
    root.title("🧠 VurnVigil, a vulnerability scanner")
    root.geometry("900x600")
    root.configure(bg="#1f1f1f")

    title = tk.Label(root, text="👾 VurnVigil", bg="#1f1f1f",
                     fg="lime", font=("Helvetica", 20, "bold"))
    title.pack(pady=10)

    button_frame = tk.Frame(root, bg="#1f1f1f")
    button_frame.pack(pady=10, fill="x")

    def open_url_scanner():
        global url_scanner_window
        if url_scanner_window is None or not url_scanner_window.winfo_exists():
            url_scanner_window = launch_url_scanner()
        else:
            url_scanner_window.lift()

    def open_folder_scanner():
        global folder_scanner_window
        if folder_scanner_window is None or not folder_scanner_window.winfo_exists():
            folder_scanner_window = launch_folder_scanner()
        else:
            folder_scanner_window.lift()

    def clear_output():
        if url_scanner_window and url_scanner_window.winfo_exists():
            url_scanner_window.clear_output()
        if folder_scanner_window and folder_scanner_window.winfo_exists():
            folder_scanner_window.clear_output()

    def save_output():
        if url_scanner_window and url_scanner_window.winfo_exists():
            url_scanner_window.save_output()
        if folder_scanner_window and folder_scanner_window.winfo_exists():
            folder_scanner_window.save_output()

    btn_url_scan = tk.Button(button_frame, text="🌐 URL Scanner", command=open_url_scanner,
                             width=15, height=2, bg="#00bcd4", fg="black", font=("Arial", 12))
    btn_url_scan.grid(row=0, column=0, padx=8)

    btn_folder_scan = tk.Button(button_frame, text="📁 Folder Scanner", command=open_folder_scanner,
                                width=15, height=2, bg="#4caf50", fg="white", font=("Arial", 12))
    btn_folder_scan.grid(row=0, column=1, padx=8)

    btn_clear = tk.Button(button_frame, text="🧹 Clear Output", command=clear_output,
                          width=15, height=2, bg="#f4511e", fg="white", font=("Arial", 12))
    btn_clear.grid(row=0, column=2, padx=8)

    btn_save = tk.Button(button_frame, text="💾 Save Output", command=save_output,
                         width=15, height=2, bg="#00c853", fg="white", font=("Arial", 12))
    btn_save.grid(row=0, column=3, padx=8)

    btn_port_scan = tk.Button(button_frame, text="🔍 Port Scanner", state="disabled",
                              width=15, height=2, font=("Arial", 12))
    btn_port_scan.grid(row=0, column=4, padx=8)

    root.mainloop()

if __name__ == "__main__":
    main_gui()
