import socket
import whois
import requests
from urllib.parse import urlparse

def scan_url(url):
    try:
        parsed = urlparse(url)
        domain = parsed.netloc or parsed.path
        results = {"Domain": domain}

        try:
            ip = socket.gethostbyname(domain)
            results["IP Address"] = ip
        except Exception as e:
            results["IP Address"] = f"Error: {e}"

        try:
            w = whois.whois(domain)
            results["WHOIS"] = {
                "Name": w.name,
                "Registrar": w.registrar,
                "Creation Date": str(w.creation_date)
            }
        except Exception as e:
            results["WHOIS"] = f"Error: {e}"

        try:
            r = requests.get(url, timeout=5)
            results["Headers"] = dict(r.headers)
        except Exception as e:
            results["Headers"] = f"Error: {e}"

        return results
    except Exception as e:
        return {"error": str(e)}
