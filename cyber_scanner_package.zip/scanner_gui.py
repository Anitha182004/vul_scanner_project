import os
import re
import json
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, Toplevel

# Import your actual URL scanning function here (you must implement this)
# For now, this is a placeholder stub
def scan_url(url):
    # Simulate scanning; replace with your real scanner logic
    if "fail" in url:
        return {"error": "Failed to reach URL"}
    return {
        "Status": "OK",
        "URL": url,
        "Vulnerabilities Found": {
            "SQL Injection": "None",
            "XSS": "None",
            "CSRF": "Potential"
        }
    }

VULN_PATTERNS = {
    "Hardcoded Password": r"(password\s*=\s*['\"]).+?(['\"])",
    "SQL Injection Risk": r"(SELECT|INSERT|UPDATE|DELETE).+?(\"|')\s*\+\s*(\"|')",
    "Command Injection": r"os\.system\(",
    "Eval Usage": r"\beval\(",
    "Pickle Deserialization": r"\bpickle\.load\(",
    "Weak Random": r"\brandom\.random\(",
    "Insecure Hash (MD5)": r"\bhashlib\.md5\(",
    "Input() usage (Py2)": r"\binput\(",
}

# --------------- URL Scanner GUI ---------------
def display_results(results, output_box):
    output_box.delete("1.0", tk.END)
    for key, value in results.items():
        if isinstance(value, dict):
            output_box.insert(tk.END, f"{key}:\n")
            for k2, v2 in value.items():
                output_box.insert(tk.END, f"  {k2}: {v2}\n")
        else:
            output_box.insert(tk.END, f"{key}: {value}\n")

def launch_url_scanner():
    window = Toplevel()
    window.title("🔍 URL Scanner")
    window.geometry("700x500")
    window.configure(bg="#1e1e1e")

    label = tk.Label(window, text="Enter URL to scan:", fg="cyan", bg="#1e1e1e", font=("Arial", 14))
    label.pack(pady=10)

    url_entry = tk.Entry(window, width=60, font=("Arial", 12))
    url_entry.pack(pady=5)

    output_box = tk.Text(window, height=20, width=80, bg="#121212", fg="white", font=("Consolas", 11))
    output_box.pack(padx=10, pady=10)

    def scan_url_gui():
        url = url_entry.get().strip()
        if not url:
            messagebox.showwarning("Input Error", "Please enter a URL to scan.")
            return
        if not (url.startswith("http://") or url.startswith("https://")):
            messagebox.showwarning("Input Error", "URL must start with http:// or https://")
            return

        output_box.delete("1.0", tk.END)
        output_box.insert(tk.END, f"🌐 Scanning {url}...\n")
        results = scan_url(url)

        if "error" in results:
            output_box.insert(tk.END, f"❌ Failed: {results['error']}\n")
        else:
            display_results(results, output_box)

    tk.Button(window, text="Scan URL", command=scan_url_gui,
              bg="#00bcd4", fg="black", font=("Arial", 12, "bold")).pack(pady=10)

    def clear_output():
        output_box.delete("1.0", tk.END)

    def save_output():
        text_data = output_box.get("1.0", tk.END)
        save_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                                 filetypes=[("Text files", "*.txt"), ("JSON files", "*.json")])
        if save_path:
            try:
                if save_path.endswith(".json"):
                    with open(save_path, "w", encoding="utf-8") as f:
                        json.dump({"output": text_data}, f, indent=4)
                else:
                    with open(save_path, "w", encoding="utf-8") as f:
                        f.write(text_data)
                messagebox.showinfo("Saved", "Output saved successfully!")
            except Exception as e:
                messagebox.showerror("Save Error", str(e))

    window.clear_output = clear_output
    window.save_output = save_output

    return window


# --------------- Folder Scanner GUI ---------------
def launch_folder_scanner():
    window = Toplevel()
    window.title("📁 Folder Vulnerability Scanner")
    window.geometry("900x600")
    window.configure(bg="#1e1e1e")

    output = scrolledtext.ScrolledText(window, width=110, height=28, bg="#263238", fg="#ffffff")
    output.pack(pady=10)
    output.tag_config("vuln", foreground="orange")
    output.tag_config("error", foreground="red")
    output.tag_config("safe", foreground="green")

    def scan_file(file_path):
        findings = []
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            output.insert(tk.END, f"❌ Error reading {file_path}: {e}\n", "error")
            return []

        for vuln_name, pattern in VULN_PATTERNS.items():
            for match in re.finditer(pattern, content, re.IGNORECASE):
                line_number = content[:match.start()].count("\n") + 1
                output.insert(tk.END, f"[{vuln_name}] in {file_path} at line {line_number}\n", "vuln")
                findings.append({"vulnerability": vuln_name, "line": line_number})
        return findings

    def scan_folder(folder_path):
        output.insert(tk.END, f"\n🔍 Scanning: {folder_path}\n\n", "safe")
        results_dict = {}
        for root_dir, _, files in os.walk(folder_path):
            for file in files:
                if file.endswith((".py", ".js", ".php")):
                    full_path = os.path.join(root_dir, file)
                    findings = scan_file(full_path)
                    if findings:
                        results_dict[full_path] = findings
        return results_dict

    def run_scan():
        output.delete("1.0", tk.END)
        folder = filedialog.askdirectory(title="Select Folder to Scan")
        if folder:
            results = scan_folder(folder)
            if not results:
                output.insert(tk.END, "No vulnerabilities found! 🛡️\n", "safe")
            else:
                output.insert(tk.END, "\nScan completed!\n", "safe")

    btn_scan = tk.Button(window, text="Select Folder & Scan", command=run_scan,
                         bg="#4caf50", fg="white", font=("Arial", 12, "bold"))
    btn_scan.pack(pady=10)

    def clear_output():
        output.delete("1.0", tk.END)

    def save_output():
        text_data = output.get("1.0", tk.END)
        save_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                                 filetypes=[("Text files", "*.txt"), ("JSON files", "*.json")])
        if save_path:
            try:
                if save_path.endswith(".json"):
                    lines = text_data.strip().split("\n")
                    json_data = {"output_lines": lines}
                    with open(save_path, "w", encoding="utf-8") as f:
                        json.dump(json_data, f, indent=4)
                else:
                    with open(save_path, "w", encoding="utf-8") as f:
                        f.write(text_data)
                messagebox.showinfo("Saved", "Output saved successfully!")
            except Exception as e:
                messagebox.showerror("Save Error", str(e))

    window.clear_output = clear_output
    window.save_output = save_output

    return window
