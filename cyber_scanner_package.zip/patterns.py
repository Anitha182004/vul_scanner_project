pattern_list = [
    {"type": "web", "pattern": r"<script>.*?</script>", "risk": 7},
    {"type": "web", "pattern": r"document\.cookie", "risk": 6},
    {"type": "network", "pattern": r"\b\d{1,3}(\.\d{1,3}){3}\b", "risk": 3},
    {"type": "software", "pattern": r"eval\(", "risk": 6},
    {"type": "api", "pattern": r"Authorization:\s*Bearer\s+[A-Za-z0-9\.\-_]+", "risk": 8},
    {"type": "api", "pattern": r"api_key\s*=\s*[\'\"]?[A-Za-z0-9_\-]{16,}[\'\"]?", "risk": 9},
    {"type": "software", "pattern": r"exec\(", "risk": 7},
    {"type": "network", "pattern": r"password\s*=\s*['\"].+['\"]", "risk": 6},
    {"type": "web", "pattern": r"onerror\s*=\s*[\"'].*?[\"']", "risk": 7}
]




