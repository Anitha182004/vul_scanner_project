import socket

# Common ports (add more or use range(1, 1025) for all)
common_ports = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP",
    110: "POP3", 143: "IMAP", 443: "HTTPS", 3306: "MySQL", 8080: "HTTP-Alt"
}

def scan_ports(host, ports=common_ports.keys(), timeout=1):
    open_ports = []
    for port in ports:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(timeout)
                result = s.connect_ex((host, port))
                if result == 0:
                    open_ports.append((port, common_ports.get(port, "Unknown")))
        except Exception:
            pass
    return open_ports
